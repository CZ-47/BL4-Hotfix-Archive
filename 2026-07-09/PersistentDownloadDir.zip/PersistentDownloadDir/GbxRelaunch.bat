@echo off
echo.
echo Attempting to relaunch process: Borderlands4.exe... 
echo.
set "TARGET_PID=11440"
:WAIT_FOR_PID
    tasklist /fi "pid eq %TARGET_PID%" 2>nul | find "%TARGET_PID%" >nul
    if errorlevel 1 (
        echo Process with PID %TARGET_PID% has exited.
        goto :WAIT_FINISHED
    ) else (
        echo Process with PID %TARGET_PID% is still running. Waiting...
        timeout /t 1 /nobreak >nul
        goto :WAIT_FOR_PID
    )
:WAIT_FINISHED
echo.
echo Starting process: F:\Program Files (x86)\Steam\steamapps\common\Borderlands 4\OakGame\Binaries\Win64\Borderlands4.exe... 
timeout /t 3 /nobreak >nul
start "" "F:\Program Files (x86)\Steam\steamapps\common\Borderlands 4\OakGame\Binaries\Win64\Borderlands4.exe" OakGame -initialuser=76561198074051632 -patch=cb101ed5-f30e-4689-bef4-d71efc1c6698 -relaunch
exit
